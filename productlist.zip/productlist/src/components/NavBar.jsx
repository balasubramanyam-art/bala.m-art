export default function Navbar() {
  return (
    <nav className="navbar bg-dark text-white p-3">
      <h2> Product List</h2>
    </nav>
  );
}