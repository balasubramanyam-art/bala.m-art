export default function Sort({ setSortOption }) {
  return (
    <select className="form-select my-3" onChange={(e) => setSortOption(e.target.value)}>
      <option value="">Sort By</option>
      <option value="priceLow">Price: Low to High</option>
      <option value="priceHigh">Price: High to Low</option>
      <option value="rating">Rating</option>
    </select>
  );
}