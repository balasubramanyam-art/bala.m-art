export default function ProductCard({ product }) {
  const handleAddToCart = () => {
    console.log("Added to cart:", product.name);
  };

  return (
    <div className="card p-3 m-2 shadow-sm" style={{ width: "250px" }}>
      <img src={product.image} alt={product.name} className="card-img-top" />
      <div className="card-body">
        <h5>{product.name}</h5>
        <p> {product.price}</p>
        <p> {product.category}</p>
        <p> {product.rating}</p>
        <button className="btn btn-primary" onClick={handleAddToCart}>
          Add to Cart
        </button>
      </div>
    </div>
  );
}