import ProductCard from "./ProductCard";

export default function ProductList({ products }) {
  return (
    <div className="d-flex flex-wrap justify-content-center">
      {products.map((p) => (
        <ProductCard key={p.id} product={p} />
      ))}
    </div>
  );
}