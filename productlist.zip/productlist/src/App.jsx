import { useState } from "react";
import Navbar from "./components/NavBar";
import SearchBar from "./components/SearchBar";
import Filter from "./components/Filter";
import Sort from "./components/Sort";
import ProductList from "./components/ProductList";
import { products } from "./data/products";

export default function App() {
  const [searchTerm, setSearchTerm] = useState("");
  const [category, setCategory] = useState("");
  const [sortOption, setSortOption] = useState("");

  // Filter + Search
  let filteredProducts = products.filter((p) =>
    p.name.toLowerCase().includes(searchTerm.toLowerCase())
  );
  if (category) {
    filteredProducts = filteredProducts.filter((p) => p.category === category);
  }

  // Sorting
  if (sortOption === "priceLow") {
    filteredProducts.sort((a, b) => a.price - b.price);
  } else if (sortOption === "priceHigh") {
    filteredProducts.sort((a, b) => b.price - a.price);
  } else if (sortOption === "rating") {
    filteredProducts.sort((a, b) => b.rating - a.rating);
  }

  const categories = [...new Set(products.map((p) => p.category))];

  return (
    <div>
      <Navbar />
      <div className="container my-4">
        <SearchBar searchTerm={searchTerm} setSearchTerm={setSearchTerm} />
        <Filter categories={categories} setCategory={setCategory} />
        <Sort setSortOption={setSortOption} />
        <ProductList products={filteredProducts} />
      </div>
    </div>
  );
}