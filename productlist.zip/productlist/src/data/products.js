export const products = [
  {
    id: 1,
    name: "Wireless Headphones",
    price: 99,
    category: "Electronics",
    rating: 4.5,
    image: "https://via.placeholder.com/150"
  },
  {
    id: 2,
    name: "Running Shoes",
    price: 120,
    category: "Sports",
    rating: 4.2,
    image: "https://via.placeholder.com/150"
  },
  {
    id: 3,
    name: "Coffee Maker",
    price: 75,
    category: "Home Appliances",
    rating: 4.0,
    image: "https://via.placeholder.com/150"
  }
];