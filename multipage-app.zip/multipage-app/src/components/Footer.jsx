import React from "react";

function Footer() {
  return (
    <footer style={styles.footer}>
      <p> {new Date().getFullYear()} My MultiPage App. All rights reserved.</p>
      <p>
        Built with <span style={{ color: "tomato" }}></span> using React + React Router
      </p>
    </footer>
  );
}

const styles = {
  footer: {
    backgroundColor: "#f0f0f0",
    padding: "1rem",
    textAlign: "center",
    marginTop: "2rem",
    borderTop: "1px solid #ccc",
    fontSize: "0.9rem",
  },
};

export default Footer;