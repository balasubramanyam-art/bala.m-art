import { Link } from "react-router-dom";

function About() {
  return (
    <div className="container">
      <h1>About This App</h1>
      <p>This application showcases React Router with multiple pages using Vite.</p>
      <Link to="/">Back to Home</Link>
    </div>
  );
}
export default About;