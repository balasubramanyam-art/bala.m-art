import { Link } from "react-router-dom";

function Home() {
  return (
    <div className="container">
      <h1>Hello, Welcome to the Application</h1>
      <p>This app demonstrates multi-page routing in React with Vite.</p>
      <Link to="/about">Go to About</Link> | <Link to="/users">View Users</Link>
    </div>
  );
}
export default Home;