export const applications = [
  {
    id: 1,
    jobId: 1,
    userId: 1,
    status: "Pending",
    appliedDate: "2026-01-11"
  },
  {
    id: 2,
    jobId: 2,
    userId: 1,
    status: "Reviewed",
    appliedDate: "2026-01-13"
  }
];