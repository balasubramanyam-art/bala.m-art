export const users = [
  {
    id: 1,
    name: "Balasubramanyam",
    role: "Job Seeker",
    email: "bala@example.com",
    appliedJobs: [1, 2] // job IDs
  },
  {
    id: 2,
    name: "Priya Sharma",
    role: "Employer",
    email: "priya@techsolutions.com",
    postedJobs: [1] // job IDs
  },
  {
    id: 3,
    name: "Admin User",
    role: "Admin",
    email: "admin@jobboard.com"
  }
];