export const jobs = [
  {
    id: 1,
    title: "Frontend Developer",
    company: "Tech Solutions",
    location: "Bangalore",
    category: "IT",
    description: "Build and maintain user interfaces using React.",
    salary: "₹6,00,000 per annum",
    postedDate: "2026-01-10",
    rating: 4.5
  },
  {
    id: 2,
    title: "Data Analyst",
    company: "Insight Analytics",
    location: "Hyderabad",
    category: "Data",
    description: "Analyze datasets and generate business insights.",
    salary: "₹5,50,000 per annum",
    postedDate: "2026-01-12",
    rating: 4.2
  },
  {
    id: 3,
    title: "HR Manager",
    company: "Global Corp",
    location: "Chennai",
    category: "HR",
    description: "Manage recruitment and employee relations.",
    salary: "₹7,00,000 per annum",
    postedDate: "2026-01-15",
    rating: 4.0
  }
];