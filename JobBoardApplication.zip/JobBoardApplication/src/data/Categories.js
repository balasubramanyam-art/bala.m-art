export const categories = [
  "IT",
  "Data",
  "HR",
  "Finance",
  "Marketing",
  "Design"
];