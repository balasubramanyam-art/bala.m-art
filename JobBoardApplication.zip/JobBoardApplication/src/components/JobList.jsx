import JobCard from "./JobCard";

export default function JobList({ jobs }) {
  return (
    <div className="d-flex flex-wrap justify-content-center">
      {jobs.map((job) => (
        <JobCard key={job.id} job={job} />
      ))}
    </div>
  );
}