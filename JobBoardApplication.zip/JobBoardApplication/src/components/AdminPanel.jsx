export default function AdminPanel({ jobs, users, applications }) {
  return (
    <div className="p-3 border rounded my-3">
      <h4>Admin Panel</h4>
      <p>Total Jobs: {jobs.length}</p>
      <p>Total Users: {users.length}</p>
      <p>Total Applications: {applications.length}</p>
    </div>
  );
}