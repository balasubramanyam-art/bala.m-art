export default function JobCard({ job }) {
  const handleApply = () => {
    console.log(`Applied for job: ${job.title}`);
  };

  return (
    <div className="card p-3 m-2 shadow-sm" style={{ width: "300px" }}>
      <div className="card-body">
        <h5>{job.title}</h5>
        <p>{job.company}</p>
        <p>{job.location}</p>
        <p>{job.category}</p>
        <p>{job.salary}</p>
        <p>{job.rating}</p>
        <button className="btn btn-success" onClick={handleApply}>
          Apply
        </button>
      </div>
    </div>
  );
}