export default function Filter({ categories, setCategory }) {
  return (
    <select className="form-select my-3" onChange={(e) => setCategory(e.target.value)}>
      <option value="">All Categories</option>
      {categories.map((cat, idx) => (
        <option key={idx} value={cat}>{cat}</option>
      ))}
    </select>
  );
}