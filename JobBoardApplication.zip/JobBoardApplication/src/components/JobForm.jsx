import { useState } from "react";

export default function JobForm({ addJob }) {
  const [title, setTitle] = useState("");
  const [company, setCompany] = useState("");
  const [location, setLocation] = useState("");
  const [category, setCategory] = useState("");
  const [salary, setSalary] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    const newJob = {
      id: Date.now(),
      title,
      company,
      location,
      category,
      salary,
      rating: 0
    };
    addJob(newJob);
    console.log("Job Posted:", newJob);
  };

  return (
    <form onSubmit={handleSubmit} className="p-3 border rounded my-3">
      <h4>Post a Job</h4>
      <input className="form-control my-2" placeholder="Job Title" value={title} onChange={(e) => setTitle(e.target.value)} />
      <input className="form-control my-2" placeholder="Company" value={company} onChange={(e) => setCompany(e.target.value)} />
      <input className="form-control my-2" placeholder="Location" value={location} onChange={(e) => setLocation(e.target.value)} />
      <input className="form-control my-2" placeholder="Category" value={category} onChange={(e) => setCategory(e.target.value)} />
      <input className="form-control my-2" placeholder="Salary" value={salary} onChange={(e) => setSalary(e.target.value)} />
      <button className="btn btn-primary">Post Job</button>
    </form>
  );
}