import { useState } from "react";
import Navbar from "./components/Navbar";
import SearchBar from "./components/SearchBar";
import Filter from "./components/Filter";
import Sort from "./components/Sort";
import JobList from "./components/JobList";
import JobForm from "./components/JobForm";
import AdminPanel from "./components/AdminPanel";
import { jobs as jobData } from "./data/jobs";
import { users } from "./data/users";
import { applications } from "./data/Applications";
import { categories } from "./data/Categories";

export default function App() {
  const [jobs, setJobs] = useState(jobData);
  const [searchTerm, setSearchTerm] = useState("");
  const [category, setCategory] = useState("");
  const [sortOption, setSortOption] = useState("");

  // Filter + Search
  let filteredJobs = jobs.filter((j) =>
    j.title.toLowerCase().includes(searchTerm.toLowerCase())
  );
  if (category) {
    filteredJobs = filteredJobs.filter((j) => j.category === category);
  }

  // Sorting
  if (sortOption === "salaryLow") {
    filteredJobs.sort((a, b) => parseInt(a.salary) - parseInt(b.salary));
  } else if (sortOption === "salaryHigh") {
    filteredJobs.sort((a, b) => parseInt(b.salary) - parseInt(a.salary));
  } else if (sortOption === "rating") {
    filteredJobs.sort((a, b) => b.rating - a.rating);
  }

  const addJob = (newJob) => setJobs([...jobs, newJob]);

  return (
    <div>
      <Navbar />
      <div className="container my-4">
        <SearchBar searchTerm={searchTerm} setSearchTerm={setSearchTerm} />
        <Filter categories={categories} setCategory={setCategory} />
        <Sort setSortOption={setSortOption} />
        <JobList jobs={filteredJobs} />
        <JobForm addJob={addJob} />
        <AdminPanel jobs={jobs} users={users} applications={applications} />
      </div>
    </div>
  );
}